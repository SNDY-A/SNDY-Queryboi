export default function Home() {
  return <div className='text-2xl font-bold'>Welcome to the Control Center</div>;
}