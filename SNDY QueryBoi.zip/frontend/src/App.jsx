function App() {
  return <div className='p-6 text-xl'>👋 Hey! I'm your Avatar Assistant.</div>;
}

export default App;
