# Avatar Assistant ✨

Smart NLP-Driven Assistant UI for SQL/Mongo Backends.

## Features
- Prompt-based query
- Visual dashboard
- Avatar with chat
- Safe-mode + toggle switches
